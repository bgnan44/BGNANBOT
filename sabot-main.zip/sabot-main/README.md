<p align="center">
<img src="https://i.pinimg.com//originals//7a//1b//04//7a1b04ac499abbf2bdb03ba512e19b13.jpg" widht="200px" height="200px"/>
</p>
<br>
<p align="center">
<a href="#"><img title="sabot" src="https://img.shields.io/badge/SABOT-blue?colorA=#33c5ea&colorB=#06333e&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-1.0-cyan.svg"></a>
</p>
<p align="center">
<a href="https://github.com/sanzorez"><img title="Author" src="https://img.shields.io/badge/Author-sanzorez-magenta.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/sanzorez/followers"><img title="Followers" src="https://img.shields.io/github/followers/sanzorez?color=blue&style=flat-square"></a>
<a href="https://github.com/sanzorez/saabot/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/sanzorez/sabot?color=red&style=flat-square"></a>
<a href="https://github.com/sanzorez/sabot/network/members"><img title="Forks" src="https://img.shields.io/github/forks/sanzorez/sabot?color=red&style=flat-square"></a>
<a href="https://github.com/sanzorez/sabot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/sanzorez/sabot?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/sanzorez/sabot&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>

<details>
<summary>Touch Me!!</summary>

## Ingredient/Bahan
```bash
> Android Version
> termux
> WhatsApp
> 2 HandPhone

> Laptop Version
> Gunakan Terminal Git bash Atau sejenisnya
> Sudah Terinstall Node Js Dan Sudah Ter Add path
```
## Install On Termux

```bash
> termux-setup-storage
(allow it)
> pkg update -y
> pkg upgrade -y
> pkg install git -y
> git clone https://github.com/sanzorez/sabot
> cd sabot
> npm cache clear
> bash install.sh
> npm audit fix
> npm start / node index.js
> scan Qr xd
```

## Install On Windows

- Download libwebp & tutorial [here](https://developers.google.com/speed/webp/download)
- Download FFmpeg [here](https://ffmpeg.org/download.html) - Tutorial Installing [here](http://blog.gregzaal.com/how-to-install-ffmpeg-on-windows/)
- Download Wget & tutorial [here](http://gnuwin32.sourceforge.net/packages/wget.htm)
- Download tesseract-ocr [here](https://tesseract-ocr.github.io/tessdoc/Downloads.html) - Tutorial Installing [here](https://emop.tamu.edu/Installing-Tesseract-Windows8)
- Download NodeJS [here](https://nodejs.org/en/download/)
- Download Git [here](https://git-scm.com/downloads) - Tutorial Installing [here](https://phoenixnap.com/kb/how-to-install-git-windows)

```bash
> Download Node js Dan add to path
> Download Git For Windows
> Download ffmpeg and add to path
( install both / Install keduanya )
( if that is all done installed / jika  semua sudah terinstall )
> git clone https://github.com/sanzorez/sabot
> cd sabot
> bash install.sh
> npm start
> Scan Qr xD
```
</details>

## Features


| INFO | YES
| :---------------------------------------------: | :-----------: |
|  Daftar|✅|
| CR |✅|
| Brando Cita Cita |✅|

|  CREATOR MENU  |  YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker |✅|
| Sticker Gif Maker |✅|
| Sticker To Image |✅|
| Video To MP3 |✅|
| Ttp Maker |✅|
| Attp Maker |✅|
| Black Pink Logo Maker |✅|
| Porn Hub Logo Maker |✅|
| 3D Text Maker |✅|
| 3D Box Text Maker |✅|
| Coffe Text Makee |✅|
| Coffe2 Text Maker |✅|
| Heker Text Maker |✅|
| Glitch |✅|
| blueneontext |✅|
| breakwalltext |✅|
| 3dbox |✅|  
| tahta |✅| 
| tlight |✅| 
| 8bittext |✅|  
| googlecaritext |✅| 
| dropwatertext |✅| 
| flowertext |✅| 
| glowtext |✅| 
| smoketext |✅|
| skytext |✅| 
| retrotext |✅|
| snowwrite |✅|
| watercolor |✅|
| firework |✅|
| sandwrite |✅|
| crismes |✅|
| naruto |✅|
| goldbutto |✅| 
| silverbutton |✅| 
| leavest |✅| 
| glitch |✅|
| tts |✅| 
| cpaper |✅|
| Quote Maker|✅|
| Water Maker|✅|
| Fire Text Maker |✅|
| Marvel Logo Maker |✅|
| Snow Write Maker |✅|
| Ninja Logo Maker |✅|
| Logo Wolf Maker |✅|
| And much more |✅|

| MEDIA DOWNLOADER | YES |
| :-----------------: | :-------: |
| YT Search|✅|
| Play Downloader|✅|
| Ytmp3 Downloader |✅|
| Ytmp4 Downloader|✅|
| Instagram Downloader|✅|
| Tiktok Downloader|✅|
| Facebook Downloader|✅|
| Joox Downloader|❌|
| Trend Twit|✅|
| Wattpad Search|✅|

| DOWNLOADER FUN| YES |
| :-----------------: | :-------: |
| Pinterest Downloader|✅|
| Get downloader |✅|

| MEME | YES |
| :-----------------: | :-------: |
| Meme|✅|
| Meme Indo|✅|
| Dark Jokes|✅|

| GROUP | YES |
| :-----------------: | :-------: |
| Anti link|✅|
| Open Group|✅|
| Link Group|✅|
| info Group|✅|
| Close Group|✅|
| Promote Member|✅|
| Demote Member|✅|
| Hide Tag|✅|
| Tag All Members|✅|
| Add Member|✅|
| Kick Member|✅|
| Show List Admins|✅|
| Leave Group|✅|
| Show Owner Group|✅|
| welcome New Members|✅|
| Nsfw|✅|

| SOUND | YES |
| :-----------------: | :-------: |
| iri |✅|
| tapi |✅|
| bernyanyi |✅|
| pale |✅|
| anjay |✅|
| azab |✅|
| ah |✅|
| eh |✅|
| anjg |✅|
| hayyuk |✅|
| ph |✅|
| polish |✅|
| rampam |✅|
| ratata |✅|
| sad |✅|
| sedih |✅|
| tapi |✅|
| tobat |✅|
| tokped |✅|
| yahaha |✅|
 
| MUSIC FUN | YES |
| :-----------------: | :-------: |
| Music Lyrics|✅|
| Chord Guitar|✅|

| ISLAM | YES |
| :-----------------: | :-------: |
| Qur'an|✅|
| Qur'an Surah 1,2,3 dll |✅|

| STALK | YES |
| :-----------------: | :-------: |
| Instagram Stalk|✅|
| Tiktok Stalk|❌|

| WIBU | YES |
| :-----------------: | :-------: |
| Waifukawai|✅|
| Neonime|✅|
| Pokemon|✅|
| Nekonime|✅|
| Shota|✅|
| Kaneki|✅|
| Touka chan|✅|
| Naruto|✅|
| Loli|❌|
| Random Shota|✅|
| Random Waifu|✅|
| Random Anime|✅|
| And much more|✅|

| FUN | YES |
| :-----------------: | :-------: |
| Kucing|✅|
| Anjing|✅|
| Alay|✅|
| hilih|✅|
| Cek Ganteng|✅|
| Cantik cek|✅|
| Watak|✅|
| Quotes bucin|✅|
| Kata Cinta|✅|
| Random Hobby|✅|
| Search Image [optional]|✅|
| Pinterest [Optional] |✅|
| Truth Or Dare |✅|
| Dark Jokes|✅|
| Apakah|✅|
| Kapankah|✅|
| Bisakah|✅|
| Rate|✅|

| INFORMATION | YES |
| :-----------------: | :-------: |
| List Bahasa tts|✅|
| Information Weather|✅|
| KBBI|✅|
| Fakta|✅|
| Covid|✅|
| Jadwal Tv|✅|
| Gempa Terkini|❌|

| 18+ | NO |
| :-----------------: | :-------: |
| Random Hentai|❌|
| NSFW Neko|❌|
| NSFW Blowjob |❌|
| NSFW Loli|❌|
| NSFW Anime|✅|
| Asupan|✅|

| OWNER | YES |
| :-----------------: | :-------: |
| Add bucin|✅|
| Set Prefix|✅|
| Set PP bot|✅|
| Set Limit Harian|✅|
| Set Limit Member Group|✅|
| Set Reply Chat|✅|
| add premium |✅|
| Banned Member|✅|
| Unbanned Member|✅|
| Block Member|✅|
| Unblock Member|✅|
| remove premium |✅|
| Block Member|✅|
| Broadcast|✅|
| Group Broadcast|✅|
| Clear All Chat|✅|
| Bott aktif/nonaktif|✅|

 ABOUT BOT | YES |
| :-----------------: | :-------: |
| Info|✅|
| Premium List|✅|
| User list|✅|
| Banned list|✅|
| Block list|✅|

## Note

* Give mee Stars 🌟 

* En : If there is something that is not fixed, correct it yourself Lord xD!!
* Id : Jika ada yg tidak fix ,Benerin Sendiri Kak xD!!

## Special Thanks

* <a href="https://github.com/adiwajshing/baileys"><img alt="GitHub" src="https://img.shields.io/badge/adiwajshing-%23121011.svg?&style=for-the-badge&logo=github&logoColor=blue"/></a>
* <a href="https://github.com/mhankbarbar"><img alt="GitHub" src="https://img.shields.io/badge/MhankBarBar%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=blue"></a>
* <a href="https://github.com/4NK3R-PRODUCT1ON"><img alt="GitHub" src="https://img.shields.io/badge/4NK3R%5FPRODUCT1ON-%23121011.svg?&style=for-the-badge&logo=github&logoColor=blue"/></a>
* <a href="https://github.com/Fxc7"><img alt="GitHub" src="https://img.shields.io/badge/Fxc7-%23121011.svg?&style=for-the-badge&logo=github&logoColor=blue"/></a>
## Contact Me On
* <a href="https://wa.me/6289656439589"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-%23121011.svg?style=for-the-badge&logo=whatsapp&logoColor=green"/></a>
