// menu fitur bot
const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal, anjicc) =>  { 
  return `
❏ 「 *${name}* 」<

❘► *Nama User* : *@${pushname2}*
❘► *Aktif* : ${kyun(uptime)}
❘► *Jam* : *${jam} WIB*
❘► *Tanggal* : *${tanggal}*

❏ 「 *STATUS* 」<

❘► *Verification* : *Terverifikasi シ︎*
❘► *Speed* : *${anjicc.toFixed(4)}* _Detik_
❘► *Limit* : *${limitt}* _perhari_
❘► *Version* : *6.5.0*
❘► *User Terdaftar* : *${user.length}* _User_

❏ 「 *RULES* 」<

❘► *SPAM* _dapat menyebabkan bot delay_
❘► *CALL & VC* _tanggung sendiri bro_

❘► *Youtube* : *${yt}*
❘► *Instagram* : *${instagram}*
❘► *GitHub* : *https://github.com/sanzorez/sabot*

❏ 「 *ABOUT ${name}* 」<

❘► *${prefix}report* _lapor bug_
❘► *${prefix}info*
❘► *${prefix}donasi*
❘► *${prefix}owner*
❘► *${prefix}speed*
❘► *${prefix}daftar*
❘► *${prefix}limit*
❘► *${prefix}totaluser*
❘► *${prefix}blocklist*
❘► *${prefix}banlist*
❘► *${prefix}premiumlist*
❘► *${prefix}bahasa* _daftar bahasa translate_

❏ 「 *MEDIA DOWNLOADER* 」<

❘► *${prefix}igimg* _link foto ig valid_
❘► *${prefix}igvid* _link video ig valid_
❘► *${prefix}instastory* _username_
❘► *${prefix}tiktokdl* _link video tiktod valid_
❘► *${prefix}igstalk* _sanzedits__
❘► *${prefix}tiktokstalk* _username_
❘► *${prefix}ssweb* _url_
❘► *${prefix}url2img* _url_
❘► *${prefix}fototiktok*
❘► *${prefix}kbbi* _Apa_
❘► *${prefix}wait* _reply gambar_
❘► *${prefix}trendtwit*
❘► *${prefix}google* _berita terkini_

❏ 「 *CREATOR MENU* 」<

❘► *${prefix}nulis* _Naon_
❘► *${prefix}emoji* _😊_
❘► *${prefix}quotemaker* _tx/wtrmk/tema_

❘► *${prefix}attp* _Naon_ _(Don't Emote Text Only)_
❘► *${prefix}ttp* _Naon_ _(Don't Emote Text Only)_
❘► *${prefix}ttp2* _Naon_ _(Don't Emote Text Only)_
❘► *${prefix}ttp3* _Naon_ _(Don't Emote Text Only)_
❘► *${prefix}ttp4* _Naon_ _(Don't Emote Text Only)_
❘► *${prefix}epep*
❘► *${prefix}pubglogo* _Naon/tes_
❘► *${prefix}phlogo* _Naon/tes_
❘► *${prefix}hpotterlogo* _Naon_
❘► *${prefix}bfieldlogo* _Naon/Naon_
❘► *${prefix}bpinklogo* _Naon_
❘► *${prefix}wolflogo* _Naon_
❘► *${prefix}coffe* _Naon_
❘► *${prefix}coffe2* _Naon_
❘► *${prefix}love* _Naon_
❘► *${prefix}3d* _Naon_
❘► *${prefix}3dbox* _Naon_
❘► *${prefix}tahta* _Naon_
❘► *${prefix}tlight* _Naon_
❘► *${prefix}8bittext* _Naon/Naon_
❘► *${prefix}googlecaritext* _Naon/Naon/Naon_
❘► *${prefix}hekertext* _Naon_
❘► *${prefix}lighttext* _Naon_
❘► *${prefix}flametext* _Naon_
❘► *${prefix}blueneontext* _Naon_ *(NEW)*
❘► *${prefix}breakwalltext* _Naon_ *(NEW)*
❘► *${prefix}dropwatertext* _Naon_ *(NEW)*
❘► *${prefix}flowertext* _Naon_ *(NEW)*
❘► *${prefix}glowtext* _Naon_
❘► *${prefix}smoketext* _Naon_ *(NEW)*
❘► *${prefix}skytext* _Naon_ *(NEW)*
❘► *${prefix}retrotext* _Naon_ *(NEW)*
❘► *${prefix}snowwrite* _Naon_ *(NEW)*
❘► *${prefix}watercolor* _Naon_ *(NEW)*
❘► *${prefix}firework* _Naon_ *(NEW)*
❘► *${prefix}sandwrite* _Naon_ *(NEW)*
❘► *${prefix}crismes* _Naon_
❘► *${prefix}naruto* _Naon_
❘► *${prefix}goldbutton* _Naon_
❘► *${prefix}silverbutton* _Naon_
❘► *${prefix}leavest* _Naon_
❘► *${prefix}glitch* _Naon/tes/b_
❘► *${prefix}tts* _id Haii_
❘► *${prefix}cpaper* _Naon_
❘►
❘► *${prefix}stiker*
❘► *${prefix}gifstiker*
❘► *${prefix}toimg*
❘► *${prefix}img2url*
❘► *${prefix}tomp3*
❘► *${prefix}ocr*
❘► *${prefix}get* _loli_ _(image yang mau dicari)_

❏ 「 *GROUP ONLY* 」<

❘► *${prefix}modeanime* _On/Off_
❘► *${prefix}neonime naruto*
❘► *${prefix}naruto*
❘► *${prefix}minato*
❘► *${prefix}boruto*
❘► *${prefix}hinata*
❘► *${prefix}sakura*
❘► *${prefix}sasuke*
❘► *${prefix}toukachan*
❘► *${prefix}rize*
❘► *${prefix}akira*
❘► *${prefix}itori*
❘► *${prefix}kurumi*
❘► *${prefix}miku*
❘► *${prefix}anime*
❘► *${prefix}animecry*
❘► *${prefix}animekiss*

❏ 「 *GROUP ONLY* 」<

❘► *${prefix}antilink* _On/Off_
❘► *${prefix}welcome* _On/Off_
❘► *${prefix}grup* _buka/tutup_
❘► *${prefix}ownergrup*
❘► *${prefix}setpp*
❘► *${prefix}infogc*
❘► *${prefix}add* _628xxxxxxxxxx_
❘► *${prefix}kick* _@@tagg_
❘► *${prefix}kicktime* _@@tagg_
❘► *${prefix}promote* _@@tagg_
❘► *${prefix}demote* _@@tagg_
❘► *${prefix}setname* _what_
❘► *${prefix}setdesc* _message_
❘► *${prefix}linkgrup*
❘► *${prefix}tagme*
❘► *${prefix}hidetag*
❘► *${prefix}tagall*
❘► *${prefix}mentionall*
❘► *${prefix}fitnah* _@@tagg/isi/balasan_
❘► *${prefix}listadmin*

❏ 「 *GROUP ONLY ADMIN* 」<

❘► *${prefix}nsfw* _On/Off_
❘► *${prefix}nsfwloli*
❘► *${prefix}nsfwblowjob*
❘► *${prefix}nsfwneko*
❘► *${prefix}nsfwtrap*
❘► *${prefix}hentai*
❘► *${prefix}simih* _on/off_
❘► *${prefix}bot* _on/off_

❏ 「 *OTHERS FUN & GAME* 」<

❘► *${prefix}anjing*
❘► *${prefix}kucing*
❘► *${prefix}testime*
❘► *${prefix}hilih*
❘► *${prefix}apakah*
❘► *${prefix}kapankah*
❘► *${prefix}bisakah*
❘► *${prefix}cantik*
❘► *${prefix}ganteng*
❘► *${prefix}rate*
❘► *${prefix}watak*
❘► *${prefix}hobby*
❘► *${prefix}infogempa*
❘► *${prefix}infonomor*
❘► *${prefix}quotes*
❘► *${prefix}truth*
❘► *${prefix}dare*
❘► *${prefix}katabijak*
❘► *${prefix}fakta*
❘► *${prefix}darkjokes*
❘► *${prefix}bucin*
❘► *${prefix}pantun*
❘► *${prefix}katacinta*
❘► *${prefix}jadwaltvnow*
❘► *${prefix}hekerbucin*
❘► *${prefix}katailham*

❏ 「 *OTHERS FUN & GAME* 」<

❘► *${prefix}jarak* _Sumedang/Bandung_
❘► *${prefix}translate* _en/Apa kabar?_
❘► *${prefix}pasangan* _Naon/Awowkok_
❘► *${prefix}gantengcek* _Naon_
❘► *${prefix}cantikcek* _Aowkwok_
❘► *${prefix}artinama* _Naon_
❘► *${prefix}persengay* _Topan_
❘► *${prefix}pbucin* _Naon_
❘► *${prefix}bpfont* _Naon_
❘► *${prefix}textstyle* _Naon_
❘► *${prefix}jadwaltv* _antv_
❘► *${prefix}lirik* _melukis senja_
❘► *${prefix}chord* _Melukis senja_
❘► *${prefix}wiki* _Adolf Hitler_
❘► *${prefix}brainly* _pertanyaan_
❘► *${prefix}resepmasakan* _rawon_
❘► *${prefix}map* _Sumedang_
❘► *${prefix}film* _Fast and Farious_
❘► *${prefix}pinterest* _gambar kucing_
❘► *${prefix}infocuaca* _Sumedang_
❘► *${prefix}jamdunia* _Sumedang_
❘► *${prefix}mimpi* _Ular_
❘► *${prefix}infoalamat* _jalan Sumedang_
❘► *${prefix}playstore* _WhatsApp_

❏ 「 *OTHERS FUN & GAME* 」<

❘► *${prefix}readmore*
❘► *${prefix}puisiimg*
❘► *${prefix}asupan*
❘► *${prefix}fml*
❘► *${prefix}tebakgambar*
❘► *${prefix}caklontong*
❘► *${prefix}family100*
❘► *${prefix}memeindo*
❘► *${prefix}kalkulator* _13*12_
❘► *${prefix}moddroid* _lightroom_
❘► *${prefix}apkpure* _lightroom_
❘► *${prefix}searchfilm* _Doraemon_
❘► *${prefix}happymod* _lightroom_

❏ 「 *ISLAM* 」<

❘► *${prefix}jadwalsholat* _Sumedang_
❘► *${prefix}quran*
❘► *${prefix}quranlist*
❘► *${prefix}quransurah* _Naon_

❏ 「 *FIND ME SIR* 」<

❘► *${prefix}becrypt* _string_
❘► *${prefix}encode64* _string_
❘► *${prefix}decode64* _encrypt_
❘► *${prefix}encode32* _string_
❘► *${prefix}decode32* _encrypt_
❘► *${prefix}encbinary* _string_
❘► *${prefix}decbinary* _encrypt_
❘► *${prefix}encoctal* _string_
❘► *${prefix}decoctal* _encrypt_
❘► *${prefix}hashidentifier* _encrypt Hash_
❘► *${prefix}dorking* _yang mau dicari_
❘► *${prefix}pastebin* _Naon_
❘► *${prefix}tinyurl* _link_
❘► *${prefix}bitly* _link_

❏ 「 *OTHERS FUN & GAME* 」<

❘► *${prefix}spamcall* _083xxxxxxxxx_
❘► *${prefix}spamgmail* _contoh@gmail.com_

❏ 「 *HARAM FEATURE* 」<

❘► *${prefix}randomkpop*
❘► *${prefix}cersex*
❘► *${prefix}randombokep*
❘► *${prefix}pornhub* _stepMoms_
❘► *${prefix}xvideos* _japan_
❘► *${prefix}nekopoi* _oni chichi_

❏ 「 *SOUND* 」<

❘► *${prefix}iri*
❘► *${prefix}tapi*
❘► *${prefix}bernyanyi*
❘► *${prefix}pale*
❘► *${prefix}anjay*
❘► *${prefix}azab*
❘► *${prefix}ah*
❘► *${prefix}eh*
❘► *${prefix}anjg*
❘► *${prefix}hayyuk*
❘► *${prefix}ph*
❘► *${prefix}polish*
❘► *${prefix}rampam*
❘► *${prefix}ratata*
❘► *${prefix}sad*
❘► *${prefix}sedih*
❘► *${prefix}tapi*
❘► *${prefix}tobat*
❘► *${prefix}tokped*
❘► *${prefix}yahaha*

❏  「 *OWNER ONLY* 」<

❘► *${prefix}addprem* _@tagg_
❘► *${prefix}removeprem* _mention_
❘► *${prefix}setmemlimit* _Naon_
❘► *${prefix}setlimit* _Naon_
❘► *${prefix}setreply* _Naon_
❘► *${prefix}setprefix* _Naon_
❘► *${prefix}setnamebot* _Naon_
❘► *${prefix}setppbot* _Naon_
❘► *${prefix}bc* _pesan_
❘► *${prefix}bcgc* _pesan_
❘► *${prefix}ban*
❘► *${prefix}unban*
❘► *${prefix}block*
❘► *${prefix}unblock*
❘► *${prefix}clearall*
❘► *${prefix}delete*
❘► *${prefix}clone*
❘► *${prefix}getses*
❘► *${prefix}leave*

❏ 「 *PREMIUM ONLY* 」<

❘► *${prefix}play* _menepi_
❘► *${prefix}fb* _link video_
❘► *${prefix}snack* _link snack video_
❘► *${prefix}ytmp3* _link yt_
❘► *${prefix}ytmp4* _link yt_
❘► *${prefix}randomquran*
❘► *${prefix}joox* _Monolog Pamungkas_
❘► *${prefix}smule* _link video Smule_

❏ 「 *SUPPORT ${name}* 」<

❘► *O BOT*
❘► *M. HADI FIRMANSYA*
❘► *DELIA AULIA*
❘► *KEVIN DAVID*
❘► *MY TEAM FXC7 BOT*
❘► *FXC7*
❘► *FARHAN*
❘► *LOL~4NK3R-EROR*
❘► *AND ALL CONTENT CREATOR BOT WHATSAPP*
`
}

exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// donasi menu
const donasi = (name) =>  { 
  return `       
❏ 「 *DONASI SEIKHLASNYA* 」<

❘► *PULSA : 6289656439589*
❘► *DANA : 6289656439589*

❘► Dana : *15k Invite Bot Ke Grup selama 1 bulan*
❘► Pulsa : *20k Invite Bot Ke Group Selama 1 Bulan*

❘► Untuk Kelangsungan Hidup Bot Karna Kuota Mahal:V

❏ 「 *BY ${name}* 」<
`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) =>  {
return `
List Bahasa Untuk Command *${prefix}tts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitend = (pushname2) =>  {
        return`*Maaf ${pushname2} Limit Anda Hari Ini Sudah Habis\n\n Silahkan Kembali Lagi Hari Esok:)\n\n Limit Di Reset Ketik Owner Gabut:v*`
}

const limitcount = (limitCounts) =>  {
        return`
Limit Kamu: ${limitCounts}
`
}

exports.limitend = limitend
exports.limitcount = limitcount
